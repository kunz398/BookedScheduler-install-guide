<?php

interface ILoginBasePage extends IPage
{
    /**
     * @return string
     */
    public function GetResumeUrl();
}
