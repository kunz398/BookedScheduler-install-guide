<?php

class ResourcePermissionType
{
    public const None = -1;
    public const Full = 0;
    public const View = 1;
}
