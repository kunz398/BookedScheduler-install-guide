<?php

class ReservationStatus
{
    public const Created = 1;
    public const Deleted = 2;
    public const Pending = 3;
}
