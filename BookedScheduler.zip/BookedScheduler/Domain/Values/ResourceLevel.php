<?php

class ResourceLevel
{
    public const Primary = 1;
    public const Additional = 2;
}
