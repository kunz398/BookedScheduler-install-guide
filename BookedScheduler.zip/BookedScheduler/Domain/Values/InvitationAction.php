<?php

class InvitationAction
{
    public const Accept = 'accept';
    public const CancelAll = 'cancelAll';
    public const CancelInstance = 'cancelInstance';
    public const Decline = 'decline';
    public const Join = 'join';
    public const JoinAll = 'joinAll';
}
