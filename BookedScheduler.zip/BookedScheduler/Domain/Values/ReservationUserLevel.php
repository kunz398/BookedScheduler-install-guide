<?php

class ReservationUserLevel
{
    public function __construct()
    {
    }

    public const ALL = 0;
    public const OWNER = 1;
    public const PARTICIPANT = 2;
    public const INVITEE = 3;
}
