<?php

class ReservationTypes
{
    public const Reservation = 1;
    public const Blackout = 2;
}
