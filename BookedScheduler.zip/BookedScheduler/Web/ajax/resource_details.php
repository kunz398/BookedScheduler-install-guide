<?php

define('ROOT_DIR', '../../');

require(ROOT_DIR . 'Pages/Ajax/ResourceDetailsPage.php');

$page = new ResourceDetailsPage();
$page->PageLoad();
