<?php

class ReportActions
{
    public const Generate = 'generate';
    public const PrintReport = 'print';
    public const Csv = 'csv';
    public const Save = 'save';
    public const Email = 'email';
    public const Delete = 'delete';
    public const SaveColumns = 'saveColumns';
}
